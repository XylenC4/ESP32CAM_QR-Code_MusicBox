# TelnetStream
Stream implementation over Telnet for ESP8266 and ESP32 Arduino boards package
